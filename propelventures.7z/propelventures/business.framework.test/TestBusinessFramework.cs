using Microsoft.VisualStudio.TestTools.UnitTesting;
using business.shared.Messages;
using business.framework;
using System;

namespace business.framework.test
{
    [TestClass]
    public class TestBusinessFramework

    {
        [TestMethod]
        public void CheckResultsFormat()
        {

          
            var str = new ProcessGST();
            var mockMessage = new ProcessGSTMessage { CustomerID = "Cust1234", FromDateLocal = new DateTime(2019, 3, 1, 0, 0, 0, DateTimeKind.Local), NumberMonths = 3 };
            var actual = str.PrepareAndSendReport(mockMessage);
            Assert.AreEqual(actual.IsCompleted, actual.Result);

        }
      

    }
}
