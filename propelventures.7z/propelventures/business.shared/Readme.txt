﻿This library contains all the messages and shared utilities required by the
system

- it has been stripped down for the purpose of this exercise
- do not change any existing messages