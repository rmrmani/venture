﻿using Dapper;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using business.shared.Messages;

namespace business.framework
{
    public interface IProcessGST
    {
        Task<bool>  PrepareAndSendReport(ProcessGSTMessage objProcessGSTMessage);
    }
    public sealed class ProcessGST 
    {
        private readonly string _databaseConnection;
        private readonly string _baseServiceEndpoint;

        protected string FromDate { get; private set; }
        protected string ToDate { get; private set; }

        //private IProcessGST stockFeed;
        //public ProcessGST(IProcessGST feed)
        //{
        //    stockFeed = feed;
        //}

        public ProcessGST()
        {
            _databaseConnection = ConfigurationManager.AppSettings["DatabaseConnection"];
            _baseServiceEndpoint = ConfigurationManager.AppSettings["BaseServiceEndpoint"];
        }
        public ProcessGST(string connectionstring,string baseServicepoint)
        {
            _databaseConnection = connectionstring;
            _baseServiceEndpoint = baseServicepoint;
        }
        public async Task<bool> PrepareAndSendReport(ProcessGSTMessage message)
        {
            //string customerId, DateTime fromDateLocal, int numMonths
            try
            {
                FromDate = message.FromDateLocal.ToString("yyyy-MM-dd HH:mm:ss");
                ToDate = message.FromDateLocal.AddMonths(message.NumberMonths).ToString("yyyy-MM-dd HH:mm:ss");

                var connection = new SqlConnection(_databaseConnection);

                var data = await connection.QueryAsync(
                    $@"SELECT pr.ItemValue 
					FROM PurchaseRows pr 
                    JOIN Purchase p ON p.Id = pr.PurchaseId 
                    WHERE p.CustomerId = '{message.CustomerID}' 
                        AND p.PurchaseDateUTC >= '{FromDate}' 
                        AND p.PurchaseDateUTC < '{ToDate}'");

                var purchasesTotal = 0m;
                var purchasesGstTotal = 0m;

                foreach (var pdata in data)
                {
                    purchasesTotal += Math.Round(pdata.ItemValue * 1.1m, 2);
                    purchasesGstTotal += Math.Round(pdata.ItemValue * .1m, 2);
                }

                var data2 = await connection.QueryAsync(
                    $@"SELECT ir.ItemPrice 
					FROM InvoiceRows ir 
                    JOIN Invoice i ON i.Id = ir.InvoiceId 
                    WHERE i.CustomerId = '{message.CustomerID}' 
                        AND i.InvoiceDateUTC >= '{FromDate}' 
                        AND i.InvoiceDateUTC < '{ToDate}'");

                var invoicesTotal = 0m;
                var invoicesGstTotal = 0m;

                foreach (var idata in data2)
                {
                    invoicesTotal += Math.Round(idata.ItemPrice * 1.1m, 2);
                    invoicesGstTotal += Math.Round(idata.ItemPrice * .1m, 2);
                }

                var t = SendData(message.CustomerID,
                    purchasesTotal, purchasesGstTotal,
                    invoicesTotal, invoicesGstTotal);
                t.Wait();
            }
            catch (HttpRequestException req)
            {
                Console.WriteLine(req.InnerException.ToString());
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.InnerException.ToString());
                return false;
            }
            finally
            { }
            return true;
        }

        private async Task SendData(string customerID, decimal purchasesTotal, decimal purchasesGstTotal, 
            decimal invoicesTotal, decimal invoicesGstTotal)
        {
            using (var client = new HttpClient { BaseAddress = new Uri(_baseServiceEndpoint) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "0vr67gh38dj3djsh59dkp32");
                var response = await client.PostAsync("/api/receiveGstData", new StringContent($"{{ \"customerId\" : \"{customerID}\", \"purchases\" : {{ \"total\" : \"{purchasesTotal}\", \"gst\" : \"{purchasesGstTotal}\" }}, \"invoices\" : {{ \"total\" : \"{invoicesTotal}\", \"gst\" : \"{invoicesGstTotal}\" }} }}", Encoding.UTF8, "application/json"));
            }
        }
    }
}
